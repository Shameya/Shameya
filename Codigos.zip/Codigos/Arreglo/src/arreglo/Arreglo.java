/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglo;

/**
 *
 * @author Usuario
 */
public class Arreglo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String nombre[] = new String [10];

             nombre[0] = "1 Maryury";

             nombre[1] = "2 Judy";

             nombre[2] = "3 Delmer";

             nombre[3] = "4 Kevin";

             nombre[4] = "5 Danny"; 

             nombre[5] = "6 Luis";

             nombre[6] = "7 Gerson";

             nombre[7] = "8 Erick";

             nombre[8] = "9 Jeferson";

             nombre[9] = "10 Ayniver";  //Error:No existe esta variable array de índice 4

         for(int i=0; i<nombre.length; i++){
		System.out.println(nombre[i]);
	}
	}
     }
    
    

