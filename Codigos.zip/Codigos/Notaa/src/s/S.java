/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package s;

/**
 *
 * @author Usuario
 */
public class S {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

String nombre = "Princess";
        int nota = 89;
        

System.out.println("Estudiante: " + nombre + "     " + nota); 
    
      
if(nota<69){
    System.out.print("Esta Reprobado");
    }else{
    System.out.print("Esta Aprobado");
        
    }

}//cierra método main

}//cierra class
    
    

