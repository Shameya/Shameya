/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pares;

/**
 *
 * @author Usuario
 */
public class Pares {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //NUMEROS PARES DEL 2 AL 100 con for
System.out.println("Acontinuacion se muestra la serie de numeros pares");
int x;
int y;
for(int i=2;i<50;i++)
{
x=i*2;//aqui X toma el valor del actual valor de i, multiplicado por 2
System.out.println("Numero par:"+x);
}
    }  
}
